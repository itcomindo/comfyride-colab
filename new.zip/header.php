<header id="headerpr" class="section">
    <div class="container">
        <div id="headerwr" class="hw100">
            <!-- header left -->
            <div id="headerleft" class="headercol hw100">
                <a href="/">
                    <h2><span class="comfy">Comfy</span>ride</h2>
                    <span class="logotagline">Best Ride For Special One</span>
                </a>
            </div>
            <!-- header right -->
            <div id="headerright" class="headercol hw100">
                <?php include "nav.php"; ?>
            </div>
        </div>
    </div>
</header>