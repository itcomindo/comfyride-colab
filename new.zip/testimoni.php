<section id="testimoniSection" class="section">
    <div id="testimoniCtn" class="container">
        <div class="titleTestimoni">
            <h2 class="sectionhead color2 uppercase">Happy Client's</h2>
            <p class="w80">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ducimus ex eum, ab iusto iure aliquam quis vitae deleniti impedit veniam vero totam exercitationem dolore reprehenderit beatae voluptas amet accusantium! Deserunt.</p>
        </div>
        <div class="testimoniBoxWr">
            <div class="testimoniBoxChild">
                <div class="textTestimoni">
                    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nemo cum qui voluptatibus commodi voluptate unde?</p>
                </div>
                <div class="userTestimoni">
                    <div class="imageUserTestimoni">
                        <img src="images/testimoniUser.webp" alt="Real testimonial">
                    </div>
                    <div class="nameUser">
                        <h3 class="cardhead color2">KEANU</h3>
                        <small>BUSINESS MAN</small>
                    </div>
                </div>
            </div>
            <div class="testimoniBoxChild">
                <div class="textTestimoni">
                    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nemo cum qui voluptatibus commodi voluptate unde?</p>
                </div>
                <div class="userTestimoni">
                    <div class="imageUserTestimoni">
                        <img src="images/testimoniUser.webp" alt="Real testimonial">
                    </div>
                    <div class="nameUser">
                        <h3 class="cardhead color2">KEANU</h3>
                        <small>BUSINESS MAN</small>
                    </div>
                </div>
            </div>
            <div class="testimoniBoxChild">
                <div class="textTestimoni">
                    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nemo cum qui voluptatibus commodi voluptate unde?</p>
                </div>
                <div class="userTestimoni">
                    <div class="imageUserTestimoni">
                        <img src="images/testimoniUser.webp" alt="Real testimonial">
                    </div>
                    <div class="nameUser">
                        <h3 class="cardhead color2">KEANU</h3>
                        <small>BUSINESS MAN</small>
                    </div>
                </div>
            </div>
            <div class="testimoniBoxChild">
                <div class="textTestimoni">
                    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nemo cum qui voluptatibus commodi voluptate unde?</p>
                </div>
                <div class="userTestimoni">
                    <div class="imageUserTestimoni">
                        <img src="images/testimoniUser.webp" alt="Real testimonial">
                    </div>
                    <div class="nameUser">
                        <h3 class="cardhead color2">KEANU</h3>
                        <small>BUSINESS MAN</small>
                    </div>
                </div>
            </div>
            <div class="testimoniBoxChild">
                <div class="textTestimoni">
                    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nemo cum qui voluptatibus commodi voluptate unde?</p>
                </div>
                <div class="userTestimoni">
                    <div class="imageUserTestimoni">
                        <img src="images/testimoniUser.webp" alt="Real testimonial">
                    </div>
                    <div class="nameUser">
                        <h3 class="cardhead color2">KEANU</h3>
                        <small>BUSINESS MAN</small>
                    </div>
                </div>
            </div>
            <div class="testimoniBoxChild">
                <div class="textTestimoni">
                    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nemo cum qui voluptatibus commodi voluptate unde?</p>
                </div>
                <div class="userTestimoni">
                    <div class="imageUserTestimoni">
                        <img src="images/testimoniUser.webp" alt="Real testimonial">
                    </div>
                    <div class="nameUser">
                        <h3 class="cardhead color2">KEANU</h3>
                        <small>BUSINESS MAN</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>