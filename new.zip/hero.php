<section id="heropr" class="section">
    <div class="container h100">
        <div id="herowr" class="hw100">
            <span class="herobook">Book Car Now</span>
            <span class="herophone">+62813 9891 2341</span>
            <span class="heroweb">www.comfyride.id</span>
            <div id="herocar"></div>
        </div>
    </div>
</section>